/* New Way’s website and app: small enhancements on top of normal web pages.
   Every page works without this script; it adds the app feel. */
(function () {
  'use strict';

  var reduceMotion = function () {
    return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  };

  /* ---------- Placeholder notices (as in the approved app: shown until a Square link is added) ---------- */
  function closeNotices(scope) {
    (scope || document).querySelectorAll('[data-notice]').forEach(function (button) {
      button.setAttribute('aria-expanded', 'false');
      var notice = document.getElementById(button.getAttribute('data-notice'));
      if (notice) notice.hidden = true;
    });
  }
  document.addEventListener('click', function (event) {
    var button = event.target.closest ? event.target.closest('[data-notice]') : null;
    if (!button) return;
    var notice = document.getElementById(button.getAttribute('data-notice'));
    if (!notice) return;
    var open = notice.hidden;
    closeNotices(button.closest('main'));
    notice.hidden = !open;
    button.setAttribute('aria-expanded', String(open));
  });

  /* ---------- Menu ---------- */
  var lastFocus = null;
  function menu() { return document.getElementById('site-menu'); }
  function setExpanded(value) {
    document.querySelectorAll('[data-menu-open]').forEach(function (b) { b.setAttribute('aria-expanded', value); });
  }
  function openMenu(trigger) {
    var m = menu();
    if (!m) return;
    lastFocus = trigger || document.activeElement;
    m.hidden = false;
    document.body.classList.add('menu-open');
    setExpanded('true');
    var close = m.querySelector('[data-menu-close]');
    if (close) close.focus();
  }
  function closeMenu(restoreFocus) {
    var m = menu();
    if (!m || m.hidden) return;
    m.hidden = true;
    document.body.classList.remove('menu-open');
    setExpanded('false');
    if (restoreFocus && lastFocus && document.contains(lastFocus)) lastFocus.focus();
  }
  document.addEventListener('click', function (event) {
    var opener = event.target.closest('[data-menu-open]');
    if (opener) { event.preventDefault(); openMenu(opener); return; }
    if (event.target.closest('[data-menu-close]')) closeMenu(true);
  });
  document.addEventListener('keydown', function (event) {
    var m = menu();
    if (!m || m.hidden) return;
    if (event.key === 'Escape') { closeMenu(true); return; }
    if (event.key === 'Tab') {
      var items = m.querySelectorAll('a[href], button');
      if (!items.length) return;
      var first = items[0], last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });

  /* ---------- Moving between pages without reloading (keeps the music area playing) ---------- */
  var canNavigate = 'fetch' in window && 'DOMParser' in window && history.pushState && document.getElementById('persistent');
  var navCount = 0;
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';

  function isPageLink(a, event) {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return false;
    if (a.target && a.target !== '_self') return false;
    if (a.hasAttribute('download') || a.getAttribute('rel') === 'external') return false;
    var url = new URL(a.href, location.href);
    if (url.origin !== location.origin) return false;
    if (/^\/(admin|media)(\/|$)/.test(url.pathname)) return false;
    if (/\.[a-z0-9]+$/i.test(url.pathname)) return false;
    if (url.pathname === location.pathname && url.search === location.search && url.hash) return false;
    return true;
  }

  function syncHead(doc) {
    ['meta[name="description"]', 'link[rel="canonical"]', 'meta[property="og:title"]', 'meta[property="og:description"]', 'meta[property="og:url"]'].forEach(function (sel) {
      var next = doc.querySelector(sel), current = document.querySelector(sel);
      if (next && current) {
        if (current.hasAttribute('content')) current.setAttribute('content', next.getAttribute('content'));
        if (current.hasAttribute('href')) current.setAttribute('href', next.getAttribute('href'));
      }
    });
    document.querySelectorAll('script[type="application/ld+json"]').forEach(function (s) { s.remove(); });
    doc.querySelectorAll('script[type="application/ld+json"]').forEach(function (s) { document.head.appendChild(document.importNode(s, true)); });
  }

  function navigate(href, push, scrollY) {
    var mine = ++navCount;
    closeMenu(false);
    if (push) history.replaceState({ scroll: window.scrollY }, '');
    fetch(href, { headers: { 'X-NW-Nav': '1' }, credentials: 'same-origin' })
      .then(function (res) {
        var type = res.headers.get('Content-Type') || '';
        if (type.indexOf('text/html') === -1) throw new Error('not a page');
        return res.text().then(function (text) { return { res: res, text: text }; });
      })
      .then(function (r) {
        if (mine !== navCount) return;
        var doc = new DOMParser().parseFromString(r.text, 'text/html');
        var next = doc.getElementById('page');
        var current = document.getElementById('page');
        if (!next || !current) throw new Error('no page');
        var finalUrl = r.res.url && new URL(r.res.url).origin === location.origin ? r.res.url : href;
        var hash = new URL(href, location.href).hash;
        var swap = function () {
          current.replaceWith(document.adoptNode(next));
          document.title = doc.title;
          document.body.className = doc.body.className;
          syncHead(doc);
          if (push) history.pushState({ scroll: 0 }, '', finalUrl.split('#')[0] + hash);
          var target = hash && document.getElementById(decodeURIComponent(hash.slice(1)));
          if (typeof scrollY === 'number') window.scrollTo(0, scrollY);
          else if (target) target.scrollIntoView();
          else window.scrollTo(0, 0);
          var heading = document.querySelector('#page h1');
          if (heading) heading.focus({ preventScroll: true });
          if (viewer && viewer.open) viewer.close();
          document.dispatchEvent(new CustomEvent('nw:page-changed'));
        };
        if (document.startViewTransition && !reduceMotion()) document.startViewTransition(swap);
        else swap();
      })
      .catch(function () { location.assign(href); });
  }

  if (canNavigate) {
    document.addEventListener('click', function (event) {
      var a = event.target.closest ? event.target.closest('a[href]') : null;
      if (!a || !isPageLink(a, event)) return;
      event.preventDefault();
      navigate(a.href, true);
    });
    window.addEventListener('popstate', function (event) {
      navigate(location.href, false, event.state && typeof event.state.scroll === 'number' ? event.state.scroll : 0);
    });
  }

  /* ---------- YouTube: nothing loads from YouTube until the visitor taps play ---------- */
  document.addEventListener('click', function (event) {
    var start = event.target.closest('a[data-yt]');
    if (!start || event.metaKey || event.ctrlKey || event.shiftKey) return;
    var id = start.getAttribute('data-yt');
    if (!/^[A-Za-z0-9_-]{11}$/.test(id)) return;
    event.preventDefault();
    var frame = document.createElement('iframe');
    frame.src = 'https://www.youtube-nocookie.com/embed/' + id + '?autoplay=1&rel=0&playsinline=1';
    frame.title = start.getAttribute('data-title') || 'YouTube video';
    frame.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
    frame.allowFullscreen = true;
    frame.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
    start.parentNode.replaceChild(frame, start);
    document.dispatchEvent(new CustomEvent('nw:video-play'));
  });

  /* ---------- Background music: only ever starts when the visitor taps Music ---------- */
  (function () {
    var box = document.querySelector('[data-music]');
    if (!box) return;
    var audio = box.querySelector('audio');
    var toggle = box.querySelector('[data-music-toggle]');
    var mute = box.querySelector('[data-music-mute]');
    var label = box.querySelector('.music-sr');
    var KEY = 'nw-music';
    var pref = {};
    try { pref = JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { pref = {}; }
    function save() { try { localStorage.setItem(KEY, JSON.stringify(pref)); } catch (e) { /* private browsing */ } }
    audio.volume = Math.min(1, Math.max(0, (Number(box.getAttribute('data-volume')) || 40) / 100));
    audio.muted = !!pref.muted;
    function render() {
      var playing = !audio.paused;
      box.classList.toggle('is-playing', playing);
      box.classList.toggle('is-muted', audio.muted);
      box.classList.toggle('has-started', !!pref.started);
      toggle.setAttribute('aria-pressed', String(playing));
      label.textContent = playing ? 'Pause background music' : 'Play background music';
      mute.hidden = !pref.started;
      mute.setAttribute('aria-pressed', String(audio.muted));
      mute.querySelector('.sr-only').textContent = audio.muted ? 'Unmute music' : 'Mute music';
    }
    toggle.addEventListener('click', function () {
      if (audio.paused) {
        var p = audio.play();
        pref.started = true; pref.choice = 'on'; save();
        if (p && p.catch) p.catch(function () { render(); });
      } else {
        audio.pause();
        pref.choice = 'off'; save();
      }
      render();
    });
    mute.addEventListener('click', function () {
      audio.muted = !audio.muted;
      pref.muted = audio.muted; save();
      render();
    });
    ['play', 'pause', 'volumechange'].forEach(function (e) { audio.addEventListener(e, render); });
    document.addEventListener('nw:video-play', function () { if (!audio.paused) audio.pause(); });
    render();
  })();

  /* ---------- Gallery photo viewer ---------- */
  var viewer = null;
  function openViewer(link) {
    var links = Array.prototype.slice.call(document.querySelectorAll('#page a[data-lightbox]'));
    var index = links.indexOf(link);
    if (!viewer) {
      viewer = document.createElement('dialog');
      viewer.className = 'viewer';
      viewer.setAttribute('aria-label', 'Photo');
      viewer.innerHTML = '<figure><img alt=""><figcaption></figcaption></figure>' +
        '<button type="button" class="viewer-btn viewer-close" aria-label="Close">×</button>' +
        '<button type="button" class="viewer-btn viewer-prev" aria-label="Previous photo">‹</button>' +
        '<button type="button" class="viewer-btn viewer-next" aria-label="Next photo">›</button>';
      document.body.appendChild(viewer);
      viewer.querySelector('.viewer-close').addEventListener('click', function () { viewer.close(); });
      viewer.addEventListener('click', function (e) { if (e.target === viewer) viewer.close(); });
      viewer.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowRight') viewer.querySelector('.viewer-next').click();
        if (e.key === 'ArrowLeft') viewer.querySelector('.viewer-prev').click();
      });
    }
    function show(i) {
      index = (i + links.length) % links.length;
      var l = links[index];
      var img = viewer.querySelector('img');
      img.src = l.getAttribute('href');
      img.alt = (l.querySelector('img') && l.querySelector('img').alt) || '';
      viewer.querySelector('figcaption').textContent = l.getAttribute('data-caption') || '';
    }
    viewer.querySelector('.viewer-prev').onclick = function () { show(index - 1); };
    viewer.querySelector('.viewer-next').onclick = function () { show(index + 1); };
    viewer.querySelector('.viewer-prev').hidden = viewer.querySelector('.viewer-next').hidden = links.length < 2;
    show(index);
    if (!viewer.open) viewer.showModal();
  }
  document.addEventListener('click', function (event) {
    var link = event.target.closest('a[data-lightbox]');
    if (!link || !window.HTMLDialogElement || event.metaKey || event.ctrlKey) return;
    event.preventDefault();
    openViewer(link);
  });

  /* ---------- Share your experience: the free Cloudflare Turnstile check, and clearing the stars ---------- */
  function setUpTurnstile() {
    var box = document.querySelector('#page .cf-turnstile');
    if (!box) return;
    if (window.turnstile && window.turnstile.render) { try { window.turnstile.render(box); } catch (e) { /* already shown */ } return; }
    if (document.querySelector('script[data-turnstile]')) return;
    var s = document.createElement('script');
    s.src = box.getAttribute('data-script');
    s.async = true; s.defer = true;
    s.setAttribute('data-turnstile', '');
    document.head.appendChild(s);
  }
  setUpTurnstile();
  document.addEventListener('nw:page-changed', setUpTurnstile);
  document.addEventListener('click', function (event) {
    if (!event.target.closest('[data-star-clear]')) return;
    document.querySelectorAll('#page input[name="rating"]').forEach(function (r) { r.checked = false; });
  });

  /* ---------- Installable app, private aggregate counters and offline support ---------- */
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('/sw.js').catch(function () {});
    });
  }

  function sendMetric(type, storageKey) {
    try {
      if (storageKey && localStorage.getItem(storageKey) === '1') return;
    } catch (e) { /* private browsing may block storage */ }
    fetch('/api/metrics', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: type })
    }).then(function (response) {
      if (!response.ok || !storageKey) return;
      try { localStorage.setItem(storageKey, '1'); } catch (e) { /* counting still worked */ }
    }).catch(function () {});
  }

  // One approximate unique visitor per browser profile. No identifier is sent or stored on the server.
  sendMetric('visitor', 'nw-visitor-counted-v1');

  var deferredInstallPrompt = null;
  function isStandalone() {
    return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  }
  function isIOS() { return /iphone|ipad|ipod/i.test(navigator.userAgent); }
  function isSamsungBrowser() { return /SamsungBrowser/i.test(navigator.userAgent); }
  function installButtons() { return document.querySelectorAll('[data-install-app]'); }
  function updateInstallButtons() {
    var show = !isStandalone() && (!!deferredInstallPrompt || isIOS() || isSamsungBrowser());
    installButtons().forEach(function (button) { button.hidden = !show; });
  }

  window.addEventListener('beforeinstallprompt', function (event) {
    event.preventDefault();
    deferredInstallPrompt = event;
    updateInstallButtons();
  });
  window.addEventListener('appinstalled', function () {
    deferredInstallPrompt = null;
    sendMetric('install', null);
    updateInstallButtons();
  });
  document.addEventListener('click', function (event) {
    var button = event.target.closest && event.target.closest('[data-install-app]');
    if (!button) return;
    event.preventDefault();
    if (isStandalone()) { updateInstallButtons(); return; }
    // Samsung Internet is never sent through its own install route (it produced an Android warning); Chrome is.
    if (isSamsungBrowser()) {
      alert("For the New Way’s app, open this website in Google Chrome, then tap Install New Way’s App.");
      return;
    }
    if (deferredInstallPrompt) {
      deferredInstallPrompt.prompt();
      deferredInstallPrompt.userChoice.then(function () {
        deferredInstallPrompt = null;
        updateInstallButtons();
      }).catch(function () {});
      return;
    }
    if (isIOS()) {
      alert("To install New Way’s: open this page in Safari, tap Share, then choose Add to Home Screen.");
    }
  });
  document.addEventListener('nw:page-changed', updateInstallButtons);
  updateInstallButtons();

  /* ---------- Live chat: send without leaving the page, and show replies as they arrive ---------- */
  var chatTimer = null;
  function chatSetup() {
    if (chatTimer) { clearTimeout(chatTimer); chatTimer = null; }
    var box = document.querySelector('#page [data-chat]');
    if (!box || !window.fetch) return;
    var list = box.querySelector('[data-chat-list]');
    var form = box.querySelector('[data-chat-form]');
    var after = Number(box.getAttribute('data-after')) || 0;
    var errorEl = box.querySelector('[data-chat-error]');
    var fmt = function (iso) {
      try { return new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/London', weekday: 'short', hour: 'numeric', minute: '2-digit', hour12: true }).format(new Date(iso)); } catch (e) { return ''; }
    };
    var add = function (m) {
      if (list.querySelector('[data-id="' + m.id + '"]')) return;
      var li = document.createElement('li');
      li.className = 'chat-msg chat-' + (m.from === 'you' ? 'you' : 'staff');
      li.setAttribute('data-id', m.id);
      var who = document.createElement('p'); who.className = 'chat-who'; who.textContent = (m.from === 'you' ? 'You' : (m.name || 'New Way’s')) + ' · ' + fmt(m.at);
      var body = document.createElement('p'); body.className = 'chat-body'; body.textContent = m.body;
      li.appendChild(who); li.appendChild(body); list.appendChild(li);
      after = Math.max(after, m.id);
    };
    var status = function (online) {
      var el = box.querySelector('[data-chat-status]');
      if (!el) return;
      el.className = 'chat-status ' + (online ? 'is-online' : 'is-away');
      el.querySelector('[data-chat-status-text]').textContent = online ? 'Online now' : 'Away just now';
    };
    var poll = function () {
      fetch('/chat/messages?after=' + after, { credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (d) {
          if (d && d.ok) {
            var had = after;
            (d.messages || []).forEach(add);
            status(d.online);
            if (after > had) list.lastElementChild && list.lastElementChild.scrollIntoView({ block: 'nearest' });
          }
        }).catch(function () {})
        .then(function () { if (document.body.contains(box)) chatTimer = setTimeout(poll, document.hidden ? 20000 : 5000); });
    };
    chatTimer = setTimeout(poll, 4000);
    if (list.lastElementChild) list.lastElementChild.scrollIntoView({ block: 'nearest' });
    if (!form) return;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = form.querySelector('button[type="submit"]');
      var text = form.querySelector('textarea');
      if (!text.value.trim()) { text.focus(); return; }
      var first = !!form.querySelector('[name="name"]');
      btn.disabled = true; errorEl.hidden = true;
      fetch('/chat/send', { method: 'POST', body: new FormData(form), credentials: 'same-origin', headers: { 'X-NW-Chat': '1' } })
        .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'That didn’t send. Please try again.' }; }); })
        .then(function (d) {
          btn.disabled = false;
          if (!d.ok) { errorEl.textContent = d.error || 'That didn’t send. Please try again.'; errorEl.hidden = false; return; }
          if (first) { location.reload(); return; }
          text.value = '';
          if (chatTimer) clearTimeout(chatTimer);
          poll();
        })
        .catch(function () { btn.disabled = false; errorEl.textContent = 'No connection. Please check your signal and try again.'; errorEl.hidden = false; });
    });
  }
  chatSetup();
  document.addEventListener('nw:page-changed', chatSetup);

  /* ---------- Private readings: the booking assistant asks one question at a time ---------- */
  // Without scripts all three questions show at once and the form works the same.
  function assistantSetup() {
    var form = document.querySelector('#page [data-assistant]');
    if (!form || form.getAttribute('data-ready')) return;
    form.setAttribute('data-ready', '1');
    var steps = Array.prototype.slice.call(form.querySelectorAll('[data-step]'));
    var done = form.querySelector('[data-step-done]');
    var started = steps.some(function (s) { var i = s.querySelector('input'); return (i && i.value) || s.querySelector('.field-error'); });
    if (started || !steps.length) return;
    var ok = function (input) {
      var v = input.value.trim();
      if (input.type === 'email') return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
      if (input.type === 'tel') return v.replace(/[^\d]/g, '').length >= 10;
      return v.length >= 2;
    };
    var show = function (n) {
      steps.forEach(function (s, i) { s.hidden = i > n; });
      done.hidden = n < steps.length - 1;
    };
    steps.forEach(function (s, i) {
      var input = s.querySelector('input');
      if (i === steps.length - 1) return;
      var next = document.createElement('button');
      next.type = 'button';
      next.className = 'btn-outline-gold press assistant-next';
      next.textContent = 'Next';
      var msg = document.createElement('p');
      msg.className = 'field-error';
      msg.hidden = true;
      msg.textContent = input.type === 'tel' ? 'Please enter your WhatsApp mobile number, for example 07700 900123.' : 'Please enter your full name.';
      input.parentNode.appendChild(msg);
      input.parentNode.appendChild(next);
      var go = function () {
        if (!ok(input)) { msg.hidden = false; input.focus(); return; }
        msg.hidden = true;
        next.hidden = true;
        show(i + 1);
        var nextInput = steps[i + 1].querySelector('input');
        if (nextInput) nextInput.focus();
      };
      next.addEventListener('click', go);
      input.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); go(); } });
    });
    show(0);
  }
  assistantSetup();
  document.addEventListener('nw:page-changed', assistantSetup);

  // While the customer is still using the booking pages, tell the website now and then (at most once a minute), so
  // their unfinished booking isn't counted as abandoned while they are still going.
  (function () {
    var last = Date.now();
    var ping = function () {
      var field = document.querySelector('#page input[name="draft"]');
      if (!field || !window.fetch || Date.now() - last < 60000) return;
      last = Date.now();
      fetch('/private-readings/book/active', { method: 'POST', credentials: 'same-origin', keepalive: true,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'draft=' + encodeURIComponent(field.value) }).catch(function () {});
    };
    ['input', 'change', 'pointerdown', 'keydown', 'scroll'].forEach(function (t) { document.addEventListener(t, ping, { passive: true, capture: true }); });
    document.addEventListener('nw:page-changed', function () { last = Date.now(); });
  })();

  /* ---------- Floating Chat and Music controls: never left sitting on something to tap ---------- */
  (function () {
    var lastY = window.scrollY, typing = false, ticking = false, arrival = 0;
    // When a page opens they are always shown for a few seconds, so visitors can see Music and Chat are there.
    var arrive = function () { arrival = Date.now() + 3500; setTimeout(soon, 3600); };
    var away = function () { return document.body.classList.contains('fab-away'); };
    var set = function (on) { document.body.classList.toggle('fab-away', !!on); };
    // Would the controls (where they normally sit) cover a button, link or form field on the screen now?
    var covers = function () {
      var fabs = Array.prototype.filter.call(document.querySelectorAll('.chat-fab, .music'), function (f) { return f.offsetParent || getComputedStyle(f).position === 'fixed'; });
      if (!fabs.length) return false;
      var rects = fabs.map(function (f) { var r = f.getBoundingClientRect(); var dx = away() ? r.width + 28 : 0; return { l: r.left - dx - 4, r: r.right - dx + 4, t: r.top - 4, b: r.bottom + 4, w: r.width }; })
        .filter(function (r) { return r.w > 0; });
      var targets = document.querySelectorAll('#page main a, #page main button, #page main input, #page main select, #page main textarea, #page main label, #page .site-footer a');
      for (var i = 0; i < targets.length; i++) {
        var t = targets[i];
        if (!t.offsetParent || t.closest('.trap')) continue;
        var tr = t.getBoundingClientRect();
        if (tr.bottom < 0 || tr.top > window.innerHeight || !tr.width) continue;
        for (var j = 0; j < rects.length; j++) { var f = rects[j]; if (tr.right > f.l && tr.left < f.r && tr.bottom > f.t && tr.top < f.b) return true; }
      }
      return false;
    };
    var update = function () {
      ticking = false;
      var y = window.scrollY, end = document.documentElement.scrollHeight - window.innerHeight;
      var hide;
      if (typing) hide = true;
      else if (y >= end - 24) hide = false;                // at the end of the page (the footer has room for them)
      else if (y > lastY + 6) hide = true;                  // reading down the page
      else if (y < lastY - 6 || y < 80) hide = false;       // scrolling back up, or at the top
      else hide = away();
      if (!hide && !(y < 80 && Date.now() < arrival) && covers()) hide = true;   // otherwise never left sitting on something to tap
      set(hide);
      if (Math.abs(y - lastY) > 6) lastY = y;
    };
    var soon = function () { if (!ticking) { ticking = true; requestAnimationFrame(update); } };
    window.addEventListener('scroll', soon, { passive: true });
    window.addEventListener('resize', soon);
    document.addEventListener('focusin', function (e) { if (e.target.closest && e.target.closest('input:not([type=checkbox]):not([type=radio]), textarea, select')) { typing = true; soon(); } });
    document.addEventListener('focusout', function () { typing = false; setTimeout(soon, 50); });
    document.addEventListener('nw:page-changed', function () { typing = false; lastY = window.scrollY; set(false); arrive(); setTimeout(soon, 60); });
    arrive();
    setTimeout(soon, 60);
  })();

  /* ---------- Wednesday: pay in advance (shows the running total; the server works out the real total) ---------- */
  function wedTotal() {
    var form = document.querySelector('#page [data-wed-form]');
    if (!form) return;
    var out = form.querySelector('[data-wed-total]');
    var update = function () {
      var pence = 0;
      form.querySelectorAll('select[data-price]').forEach(function (s) { pence += (Number(s.value) || 0) * (Number(s.getAttribute('data-price')) || 0); });
      out.querySelector('strong').textContent = '£' + (pence / 100).toFixed(2);
      out.hidden = false;
    };
    form.addEventListener('change', update);
    update();
  }
  wedTotal();
  document.addEventListener('nw:page-changed', wedTotal);

  /* ---------- Wednesday: straight after Continue to secure payment, open Square's payment page ---------- */
  // (The form can't be sent straight to Square: the website only lets its forms answer to itself. So the form goes to
  // the customer's own payment page here, which opens Square's page. The button stays there if this doesn't run.)
  function goToPayment() {
    var link = document.querySelector('#page a[data-go-pay]');
    if (!link || link.getAttribute('data-went')) return;
    link.setAttribute('data-went', '1');
    try { history.replaceState(history.state, '', location.pathname + location.search.replace(/([?&])go=1(&|$)/, '$1').replace(/[?&]$/, '')); } catch (e) { /* not available */ }
    location.assign(link.href);
  }
  goToPayment();
  document.addEventListener('nw:page-changed', goToPayment);

  /* ---------- Share an event (the phone's own Share menu, or copy the link) ---------- */
  function showShareButtons() {
    document.querySelectorAll('#page [data-share-url]').forEach(function (b) {
      b.hidden = !(navigator.share || (navigator.clipboard && navigator.clipboard.writeText));
    });
  }
  showShareButtons();
  document.addEventListener('nw:page-changed', showShareButtons);
  document.addEventListener('click', function (event) {
    var b = event.target.closest && event.target.closest('[data-share-url]');
    if (!b) return;
    var url = b.getAttribute('data-share-url');
    if (navigator.share) {
      navigator.share({ title: b.getAttribute('data-share-title') || '', text: b.getAttribute('data-share-text') || '', url: url }).catch(function () {});
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(url).then(function () {
        var label = b.querySelector('span');
        if (label) { var old = label.textContent; label.textContent = 'Link copied'; setTimeout(function () { label.textContent = old; }, 2000); }
      }).catch(function () {});
    }
  });

  /* ---------- Meditation download: the button can only be pressed once on this page ---------- */
  // The server decides everything (one download per purchase). This only stops a double tap and says what is
  // happening. The page is NOT reloaded automatically, because that could interrupt the download as it starts.
  document.addEventListener('submit', function (event) {
    var form = event.target.closest && event.target.closest('form[data-download-once]');
    if (!form) return;
    if (form.getAttribute('data-sent') === '1') { event.preventDefault(); return; }
    form.setAttribute('data-sent', '1');
    var button = form.querySelector('button[type="submit"]');
    setTimeout(function () {
      if (button) { button.disabled = true; button.textContent = 'Your download is starting…'; }
      var panel = form.closest('.download-panel');
      if (panel) {
        var note = document.createElement('p');
        note.className = 'notice-ok';
        note.setAttribute('role', 'status');
        note.textContent = 'Your download is starting. Please don’t press again. Check your Downloads or My Files when it finishes. Refresh this page later to see the download record.';
        panel.appendChild(note);
      }
    }, 0);
  });
})();
